PedTypes 
          
      
        
        
          
		  
          
            
              0 
              

player1 

            
            
              1 
              

player2 

            
            
              2 
              

player3 

            
            
              3 
              

player4 

            
            
              4 
              

civmale 

            
            
              5 
              

civfemale 

            
            
              6 
              

cop 

            
            
              7 
              

gang1 

            
            
              8 
              

gang2 

            
            
              9 
              

gang3 

            
            
              10 
              

gang4 

            
            
              11 
              

gang5 

            
            
              12 
              

gang6 

            
            
              13 
              

gang7 

            
            
              14 
              

gang8 

            
            
              15 
              

gang9 

            
            
              16 
              

emergency 

            
            
              17 
              

fireman 

            
            
              18 
              

criminal

            
            
              19 
              

special