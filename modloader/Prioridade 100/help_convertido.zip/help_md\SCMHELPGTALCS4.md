Sanny Builder Help: GTA LCS     Weapon numbers
          
      
        
        
          
                      
              
 !untested, incomplete
 
   
 

01B6: give_player $PLAYER_CHAR weapon 1 ammo 1
 

  
    Weapon ID 
    Model ID 
    Name 
  
  
      
      
      
  
  
    0 
    - 
    Unarmed 
  
  
    1 
    259 
      
  
  
    2 
    260 
      
  
  
    3 
    261 
      
  
  
    4 
    262 
      
  
  
    5 
    263 
      
  
  
    6 
    264 
      
  
  
    7 
    265 
      
  
  
    8 
    266 
      
  
  
    9 
    267 
      
  
  
    10 
    268 
      
  
  
    11 
    269 
      
  
  
    12 
    270 
    Grenades 
  
  
    13 
    291 
      
  
  
    14 
    271 ? 
      
  
  
    15 
    272 
      
  
  
    16 
    273 ? 
      
  
  
    17 
    274 
    Pistol 
  
  
    18 
    275 
    .357 
  
  
    19 
    277 
    Shotgun 
  
  
    20 
    278 
      
  
  
    21 
    279 
      
  
  
    22 
    281 
      
  
  
    23 
    282 
    Micro-SMG 
  
  
    24 
    283 
      
  
  
    25 
    284 
    SMG 
  
  
    26 
    280 
    M4 
  
  
    27 
    276 
    AK-47 
  
  
    28 
    285 
    Sniper Rifle 
  
  
    29 
    286 
      
  
  
    30 
    287 
    Rocket Launcher 
  
  
    31 
    288 
    Flame-Thrower 
  
  
    32 
    289 
      
  
  
    33 
    290 
    Minigun 
  
  
    34 
    ? 
      
  
  
    35 
    ? 
      
  
  
    36 
    292 
    Name