Sanny Builder Help: GTA LCS    Player Skins
          
      
        
        
          
                      
              
 0357: set_actor $PLAYER_ACTOR skin_to 'PLR3'
 

 
   
     'PLR' 
     Leone's suit 
   
   
     'PLR2' 
     Lawyer's suit 
   
   
     'PLR3' 
     Casual clothes 
   
   
     'PLR4' 
     Chauffeur's clothes 
   
   
     'PLR5' 
     Overalls 
   
   
     'PLR6' 
     Tuxedo 
   
   
     'PLR7' 
     Avenging Angel's fatigues 
   
   
     'PLR8' 
     'The King' jumpsuit 
   
   
     'PLR9' 
     Cox Mascot suit 
   
   
     'PLR10' 
     Underwear 
   
   
     'PLR11' 
     Hero garb 
   
   
     'PLR12' 
     'Dragon' jumpsuit 
   
   
     'PLR13' 
     Antonio 
   
   
     'PLR14' 
     Sweats 
   
   
     'PLR15' 
     Wiseguy 
   
   
     'PLR16' 
     Goodfella